package com.nextbuy.demo.controller;

import com.nextbuy.demo.model.Cart;
import com.nextbuy.demo.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartRepository repository;

    @GetMapping("/{id}")
    public Cart findById(@PathVariable long id) {
        return repository.findById(id).orElse(null);
    }

    @GetMapping("/")
    @ResponseBody
    public Collection<Cart> findCarts() {
        return repository.findAll();
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Cart updateCart(@PathVariable("id") final String id, @RequestBody final Cart cart) {
        return cart;
    }

}