package com.nextbuy.demo.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class Items {

    @Id
    @GeneratedValue
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cart", nullable = false)
    private Cart cart;

    public Items() {
    }
}