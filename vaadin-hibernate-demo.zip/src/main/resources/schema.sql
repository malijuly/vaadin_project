/* Generate Environment
hibernate.format_sql: true
hibernate.id.new_generator_mappings: true
hibernate.physical_naming_strategy: org.springframework.boot.orm.jpa.hibernate.SpringPhysicalNamingStrategy
hibernate.dialect: class org.hibernate.dialect.H2Dialect
hibernate.implicit_naming_strategy: org.springframework.boot.orm.jpa.hibernate.SpringImplicitNamingStrategy
*/
create sequence hibernate_sequence start with 1 increment by 1;

create table cart (
    id bigint not null,
    primary key (id)
);

create table items (
    id bigint not null,
    cart bigint not null,
    primary key (id)
);

alter table items 
    add constraint FKfd6tuahy3621vqeavy11efkv8 
    foreign key (cart) 
    references cart;
